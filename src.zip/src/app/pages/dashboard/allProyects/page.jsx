'use client'
import TableProyects from "@/app/components/tablaProyectos/TableProyects";
import { useApi } from "@/app/hooks/useApi";
import React from "react";

export default function DashboardPage() {
  const { data, loading, error } = useApi('http://localhost:3000/proyects', 'GET')

  console.log('data', data)
  if (error) alert('error al recibir la data')

  return (
    <div>
      <TableProyects data={data} />
    </div>
  );
}
