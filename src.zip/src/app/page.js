import { redirect } from "next/navigation";

export default function RedirectPage() {
  redirect("/dashboard/pages/allProyects");
}
