export const estados = [
  { label: "En progreso", value: "En progreso" },
  { label: "Completada", value: "Completada" },
  { label: "Por hacer", value: "Pendiente" },
  { label: "Cancelado", value: "Cancelado" },
];
